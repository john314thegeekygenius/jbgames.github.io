=================================================================
                Castle Adventures Demo SDL Edition
=================================================================
	This is Casle Adventures SDL Edition (DEMO). Castle Adventures
is a game made by JB Games and has no relation to the SDL Team.

	SDL can be downloaded from here: www.libsdl.org

Castle Adventures is a registered trademark of JB Games LLC.
